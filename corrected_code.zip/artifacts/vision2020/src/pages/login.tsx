import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import bannerImg from "@assets/top-banner-2026_1781259297844.webp";
import sankaraLogo from "/sankara-logo.png";
import { Eye, EyeOff, Loader2, MapPin, Calendar, Lock, User, FileText, ArrowLeft, Upload, Star, ChevronRight, KeyRound, ShieldAlert, Mail, Phone, MessageSquare } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OtpInput } from "@/components/ui/otp-input";
import { PasscodeInput } from "@/components/ui/passcode-input";

const MILESTONES = [
  { value: "3M+", label: "Free Eye Surgeries" },
  { value: "50", label: "Years of Social Impact" },
  { value: "1977", label: "Founded Since" },
];

const useInteractiveGrid = (canvasRef: React.RefObject<HTMLCanvasElement | null>) => {
  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width = canvas.offsetWidth;
    let height = canvas.height = canvas.offsetHeight;

    const points: Array<{ x: number; y: number; ox: number; oy: number; vx: number; vy: number }> = [];
    const spacing = 45;

    for (let x = spacing / 2; x < width; x += spacing) {
      for (let y = spacing / 2; y < height; y += spacing) {
        points.push({ x, y, ox: x, oy: y, vx: 0, vy: 0 });
      }
    }

    let mouse = { x: -1000, y: -1000 };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
      mouse.x = -1000;
      mouse.y = -1000;
    };

    window.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseleave", handleMouseLeave);

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      ctx.strokeStyle = "rgba(111, 66, 193, 0.05)";
      ctx.lineWidth = 1;

      points.forEach((p) => {
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 140) {
          const force = (140 - dist) / 140;
          const angle = Math.atan2(dy, dx);
          const tx = p.ox - Math.cos(angle) * force * 40;
          const ty = p.oy - Math.sin(angle) * force * 40;
          p.vx += (tx - p.x) * 0.12;
          p.vy += (ty - p.y) * 0.12;
        } else {
          p.vx += (p.ox - p.x) * 0.08;
          p.vy += (p.oy - p.y) * 0.08;
        }

        p.vx *= 0.82;
        p.vy *= 0.82;

        p.x += p.vx;
        p.y += p.vy;

        const opacity = dist < 140 ? 0.25 + (1 - dist / 140) * 0.45 : 0.12;
        ctx.fillStyle = `rgba(245, 130, 32, ${opacity})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, dist < 140 ? 2.5 : 1.2, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
      points.length = 0;
      for (let x = spacing / 2; x < width; x += spacing) {
        for (let y = spacing / 2; y < height; y += spacing) {
          points.push({ x, y, ox: x, oy: y, vx: 0, vy: 0 });
        }
      }
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [canvasRef]);
};

export default function Login() {
  const [gateway, setGateway] = useState<"delegate" | "presenter" | "staff">("delegate");

  // Form states
  const [emailInput, setEmailInput] = useState("");
  const [passcodeInput, setPasscodeInput] = useState("");
  const [staffIdentifier, setStaffIdentifier] = useState("");
  const [staffPassword, setStaffPassword] = useState("");
  const [useStaffPasscode, setUseStaffPasscode] = useState(true);
  const [showStaffForgotMsg, setShowStaffForgotMsg] = useState(false);

  const [showPassword, setShowPassword] = useState(false);
  const [showPasscodeField, setShowPasscodeField] = useState(false);
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);

  // Participant OTP flow states
  const [otpStep, setOtpStep] = useState<"email" | "otp">("email");
  const [otpValue, setOtpValue] = useState("");
  const [participantInfo, setParticipantInfo] = useState<{ id: number; name: string } | null>(null);
  const [otpSentMessage, setOtpSentMessage] = useState("");
  const [loginOtpChannel, setLoginOtpChannel] = useState<"email" | "whatsapp">("email");

  const [presenterLoginMode, setPresenterLoginMode] = useState<"otp" | "passcode">("otp");
  const [conferenceMapUrl, setConferenceMapUrl] = useState<string>("");

  const { login: setAuthContext } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const leftCanvasRef = useRef<HTMLCanvasElement | null>(null);
  useInteractiveGrid(leftCanvasRef);

  // Scramble Text Anime.js animation
  useEffect(() => {
    let active = true;
    let tlInstance: any = null;

    const initScramble = async () => {
      try {
        // @ts-ignore
        const { createTimeline, scrambleText, stagger } = await import("https://esm.sh/animejs" /* @vite-ignore */);
        if (!active) return;

        tlInstance = createTimeline({ loop: true });

        // Step 1: Foundation India centerpiece & scramble surrounding cells
        tlInstance.add(".scramble-title", {
          color: "#ffffff",
          scale: [0.9, 1],
          duration: 1200,
          ease: "outQuad",
          innerHTML: scrambleText({
            text: "SANKARA EYE FOUNDATION INDIA",
            override: " ",
            from: "center",
            cursor: "░▒▓█",
          }),
        });

        tlInstance.add(".scramble-cell", {
          opacity: [0.3, 0.9, 0.3],
          scale: [0.95, 1, 0.95],
          duration: 1000,
          innerHTML: scrambleText({
            override: " ",
            from: "center",
            cursor: "░▒▓",
            perturbation: 0.3,
          }),
        }, stagger([40, 450], { grid: [3, 4, 3], from: "center", start: "<<" }));

        // Step 2: Hospital centerpiece & scramble surrounding cells
        tlInstance.add(".scramble-title", {
          color: "#F58220",
          scale: [1, 0.95, 1],
          duration: 1400,
          ease: "outQuad",
          innerHTML: scrambleText({
            text: "SANKARA EYE HOSPITAL",
            override: false,
            from: "right",
            cursor: "░▒▓",
          }),
        }, "+=1800");

        tlInstance.add(".scramble-cell", {
          opacity: [0.3, 0.9, 0.3],
          scale: [0.95, 1, 0.95],
          duration: 1000,
          innerHTML: scrambleText({
            override: " ",
            from: "right",
            cursor: "░▒▓",
            perturbation: 0.3,
          }),
        }, stagger([40, 450], { grid: [3, 4, 3], from: "right", start: "<<" }));

        // Step 3: Meet centerpiece & scramble surrounding cells
        tlInstance.add(".scramble-title", {
          color: "#e2d5ff",
          scale: [1, 0.95, 1],
          duration: 1600,
          ease: "outQuad",
          innerHTML: scrambleText({
            text: "20th ANNUAL CONFERENCE",
            override: false,
            from: "left",
            cursor: "█▓▒░",
          }),
        }, "+=1800");

        tlInstance.add(".scramble-cell", {
          opacity: [0.3, 0.9, 0.3],
          scale: [0.95, 1, 0.95],
          duration: 1000,
          innerHTML: scrambleText({
            override: " ",
            from: "left",
            cursor: "░▒▓",
            perturbation: 0.3,
          }),
        }, stagger([40, 450], { grid: [3, 4, 3], from: "left", start: "<<" }));

        // Step 4: Conference centerpiece & scramble surrounding cells
        tlInstance.add(".scramble-title", {
          color: "#F58220",
          scale: [1, 1.05, 1],
          duration: 1600,
          ease: "outQuad",
          innerHTML: scrambleText({
            text: "VISION2020 CONFERENCE",
            override: false,
            from: "center",
            cursor: "░▒▓█",
          }),
        }, "+=1800");

        tlInstance.add(".scramble-cell", {
          opacity: [0.3, 0.9, 0.3],
          scale: [0.95, 1, 0.95],
          duration: 1000,
          innerHTML: scrambleText({
            override: " ",
            from: "random",
            cursor: "░▒▓",
            perturbation: 0.3,
          }),
        }, stagger([40, 450], { grid: [3, 4, 3], from: "center", start: "<<" }));

        // Step 5: Clear centerpiece and repeat
        tlInstance.add(".scramble-title", {
          duration: 1000,
          innerHTML: scrambleText({
            text: " ",
            override: false,
            from: "random",
            reversed: true,
            cursor: "░▒▓",
          }),
        }, "+=2500");

        tlInstance.init();
      } catch (err) {
        console.error("Failed to initialize scramble text:", err);
      }
    };

    initScramble();

    return () => {
      active = false;
      if (tlInstance) {
        try {
          tlInstance.pause();
        } catch (e) { }
      }
    };
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 80);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    fetch("/api/settings/public")
      .then((r) => r.json())
      .then((d) => {
        if (d.conferenceMapUrl) {
          setConferenceMapUrl(d.conferenceMapUrl);
        }
      })
      .catch(() => {});
  }, []);

  // Reset forms on gateway switch
  const handleGatewayChange = (val: "delegate" | "presenter" | "staff") => {
    setGateway(val);
    setOtpStep("email");
    setEmailInput("");
    setOtpValue("");
    setPasscodeInput("");
    setStaffIdentifier("");
    setStaffPassword("");
    setUseStaffPasscode(true);
  };

  // Participant OTP request
  const handleParticipantEmailSubmit = async (channel: "email" | "whatsapp" = "email") => {
    const email = emailInput.trim();
    if (!email) {
      toast({ title: "Identifier required", description: "Please enter your registered Email / Mobile / Reg No.", variant: "destructive" });
      return;
    }

    setLoginOtpChannel(channel);
    setLoading(true);
    try {
      // 1. Check for long-lived trusted browser token (10 days)
      const savedTrustedToken = localStorage.getItem(`vision2020_trusted_token_${email.toLowerCase()}`);
      const loginResp = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: email,
          trustedToken: savedTrustedToken || "",
        }),
      });

      const loginData = await loginResp.json();
      if (loginResp.ok) {
        if (!loginData.otpRequired && loginData.token) {
          // Trusted browser - bypass OTP instantly
          setAuthContext(loginData.token, loginData.user, false);
          toast({ title: `Welcome back, ${loginData.user.name}!` });
          return;
        }
      }

      // 2. Request OTP
      const otpResp = await fetch("/api/auth/participant/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: email,
          sendTo: channel,
        }),
      });

      const otpData = await otpResp.json();
      if (!otpResp.ok) {
        toast({
          title: "Failed to send OTP",
          description: otpData.error || "Please check your registered details",
          variant: "destructive",
        });
        return;
      }

      const partInfo = { id: otpData.participantId, name: otpData.participantName };
      setParticipantInfo(partInfo);
      setOtpSentMessage(otpData.message || "OTP sent successfully.");
      setOtpStep("otp");
      toast({ title: "Verification code sent ✓", description: otpData.message });
    } catch (err: any) {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // Participant OTP verification
  const handleParticipantOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!participantInfo || !otpValue.trim()) return;

    setLoading(true);
    try {
      const resp = await fetch("/api/auth/participant/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          participantId: participantInfo.id,
          otp: otpValue.trim(),
        }),
      });

      const data = await resp.json();
      if (!resp.ok) {
        toast({
          title: "Verification failed",
          description: data.error || "Invalid or expired OTP. Please try again.",
          variant: "destructive",
        });
        return;
      }

      // Store 10-day trusted token
      if (data.trustedToken) {
        localStorage.setItem(`vision2020_trusted_token_${emailInput.trim().toLowerCase()}`, data.trustedToken);
      }

      setAuthContext(data.token, data.user, false);
      toast({ title: `Welcome, ${data.user.name}!` });
    } catch {
      toast({ title: "Network error", description: "Could not verify code.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // Direct Passcode Login for Presenters
  const handlePresenterPasscodeLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = emailInput.trim().toLowerCase();
    if (!email || passcodeInput.length !== 6) {
      toast({ title: "Validation error", description: "Registered email and 6-digit passcode are required.", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const resp = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: email, password: passcodeInput }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        if (data.error === "PASSWORD_NOT_SET") {
          toast({
            title: "Passcode not configured",
            description: "Please configure your login passcode using the OTP registration pathway first.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Access denied",
            description: data.message || "Incorrect passcode. Please check and try again.",
            variant: "destructive",
          });
        }
        return;
      }
      setAuthContext(data.token, data.user, false);
      toast({ title: `Welcome, ${data.user.name}!` });
    } catch {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // Staff / Coordinator Login
  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffIdentifier || !staffPassword) return;

    setLoading(true);
    try {
      const resp = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: staffIdentifier.trim(), password: staffPassword }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        toast({
          title: "Authentication failed",
          description: data.message ?? data.error ?? "Invalid staff ID or password.",
          variant: "destructive",
        });
        return;
      }
      const mustChange = data.mustChangePassword ?? false;
      setAuthContext(data.token, data.user, mustChange);
      if (!mustChange) {
        toast({ title: `Welcome, ${data.user.name}!` });
      }
    } catch {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col lg:flex-row bg-slate-50 relative overflow-hidden font-sans">

      {/* LEFT COLUMN: BRANDING & MATRIX GRID SCRAMBLE TEXT (Desktop Only) */}
      <div className="hidden lg:flex lg:w-1/2 bg-slate-950 flex-col items-center justify-center relative overflow-hidden shrink-0 border-r border-slate-900 select-none">

        {/* Interactive Warp Dot Grid Background */}
        <canvas ref={leftCanvasRef} className="absolute inset-0 w-full h-full pointer-events-none opacity-80" />

        {/* Ambient Blur Highlights */}
        <div className="absolute top-1/4 left-1/4 w-[350px] h-[350px] bg-[#6F42C1]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-[350px] h-[350px] bg-[#F58220]/10 rounded-full blur-3xl pointer-events-none" />

        {/* The Diamond / Hexagonal Text Matrix Grid */}
        <div className="flex flex-col items-center justify-center gap-4 z-10 select-none scale-90 xl:scale-100 transition-transform">

          {/* Row 1 */}
          <div className="flex gap-6 justify-center">
            <span className="scramble-cell text-[#F58220]/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">EYE</span>
            <span className="scramble-cell text-[#F58220]/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">VISION2020</span>
            <span className="scramble-cell text-[#F58220]/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">CONFERENCE</span>
          </div>

          {/* Row 2 */}
          <div className="flex gap-6 justify-center">
            <span className="scramble-cell text-purple-400/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">HEALTH</span>
            <span className="scramble-cell text-purple-400/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">FOUNDATION</span>
            <span className="scramble-cell text-purple-400/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">MEET</span>
          </div>

          {/* Row 3 - The Centerpiece */}
          <div className="flex flex-col items-center gap-8 py-4 my-2 relative z-10 select-none">

            {/* Logo Row - Large Prominent Presentation */}
            <div className="flex gap-10 items-center justify-center flex-wrap z-20">
              <div className="hover:scale-105 transition-transform duration-300 select-none">
                <img src="/sankara-logo.png" alt="Sankara Logo" className="h-32 md:h-36 w-auto object-contain drop-shadow-[0_10px_20px_rgba(255,255,255,0.06)]" />
              </div>
              <div className="hover:scale-105 transition-transform duration-300 select-none">
                <img src="/sankara-50th-logo.png" alt="Sankara 50th Golden Jubilee Logo" className="h-32 md:h-36 w-auto object-contain drop-shadow-[0_10px_20px_rgba(255,255,255,0.06)]" />
              </div>
            </div>

            <div className="flex flex-col items-center justify-center min-w-[340px] mt-2">
              <h1 className="scramble-title text-2xl lg:text-3xl font-black font-mono tracking-widest text-white px-4 text-center leading-tight select-none">
                SANKARA EYE FOUNDATION INDIA
              </h1>
              <p className="text-[#F58220] font-bold text-xs uppercase tracking-widest mt-2.5">
                Vision 2020: 20th Annual Meet
              </p>
              <p className="text-slate-400 font-semibold text-xs text-center max-w-md mt-4 px-6 leading-relaxed">
                Join the national forum of eye care professionals and specialists collaborating to eliminate avoidable blindness and improve community eye care.
              </p>
            </div>
          </div>

          {/* Row 4 */}
          <div className="flex gap-6 justify-center">
            <span className="scramble-cell text-[#F58220]/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">BANGALORE</span>
            <span className="scramble-cell text-[#F58220]/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">JULY 2026</span>
            <span className="scramble-cell text-[#F58220]/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">DELEGATES</span>
          </div>

          {/* Row 5 */}
          <div className="flex gap-6 justify-center">
            <span className="scramble-cell text-purple-400/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">SURGERY</span>
            <span className="scramble-cell text-purple-400/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">FACULTY</span>
            <span className="scramble-cell text-purple-400/60 text-xs font-mono border border-slate-800/40 rounded-xl px-4 py-2 bg-slate-900/10 backdrop-blur-xs tracking-wider uppercase">EXCELLENCE</span>
          </div>

        </div>

        {/* Desktop Milestones Glassmorphic Banner */}
        <div className="absolute bottom-6 left-6 right-6 z-10 hidden xl:flex justify-around items-center border border-white/10 rounded-2xl bg-white/[0.03] backdrop-blur-md py-4 px-3 divide-x divide-white/10 select-none">
          <div className="flex-1 text-center">
            <span className="block text-lg font-black text-orange-400 font-mono tracking-tight">3M+</span>
            <span className="block text-[9px] text-slate-400 font-bold tracking-wider uppercase mt-0.5 leading-tight">Free Eye Surgeries<br/>Across India</span>
          </div>
          <div className="flex-1 text-center pl-2">
            <span className="block text-lg font-black text-purple-400 font-mono tracking-tight">50 Years</span>
            <span className="block text-[9px] text-slate-400 font-bold tracking-wider uppercase mt-0.5 leading-tight">Of Dedicated Service &amp;<br/>Social Impact</span>
          </div>
          <div className="flex-1 text-center pl-2">
            <span className="block text-lg font-black text-amber-400 font-mono tracking-tight">Since 1977</span>
            <span className="block text-[9px] text-slate-400 font-bold tracking-wider uppercase mt-0.5 leading-tight">Championing Eye Care<br/>&amp; Philanthropy</span>
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: LOGIN FORM SECTION */}
      <div className="flex-1 flex flex-col bg-slate-50 relative overflow-y-auto lg:overflow-hidden h-full">
        {/* Brand Color Ambient Elements (Light) */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#F58220]/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[350px] h-[350px] bg-[#6F42C1]/5 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4 pointer-events-none" />

        {/* Mobile Scramble Header (Hidden on desktop) */}
        <div className="lg:hidden w-full bg-slate-950 border-b border-slate-800 py-6 px-4 flex flex-col items-center gap-4 text-center shrink-0 z-10 shadow-lg relative overflow-hidden">
          <div className="absolute inset-0 bg-[#6F42C1]/5 blur-xl pointer-events-none" />

          <div className="flex gap-6 items-center justify-center relative z-10">
            <div className="w-16 h-16 bg-white/10 rounded-xl p-1.5 border border-white/20 shadow-lg flex items-center justify-center">
              <img src="/sankara-logo.png" alt="Sankara Logo" className="w-full h-full object-contain" />
            </div>
            <div className="w-22 h-16 bg-white/10 rounded-xl p-1.5 border border-white/20 shadow-lg flex items-center justify-center">
              <img src="/sankara-50th-logo.png" alt="Sankara 50th Golden Jubilee Logo" className="w-full h-full object-contain" />
            </div>
          </div>

          <div className="h-16 flex items-center justify-center mt-1 relative z-10">
            <h1 className="scramble-title text-lg sm:text-xl font-bold font-mono tracking-widest text-white select-none">
              SANKARA EYE FOUNDATION INDIA
            </h1>
          </div>
        </div>

        {/* Venue Information Ribbon (Desktop: z-10, Mobile: z-10) */}
        <div className="relative bg-gradient-to-r from-[#F58220] to-[#E06D10] py-2.5 px-4 shadow-sm z-10 shrink-0">
          <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-white text-xs sm:text-sm font-extrabold tracking-wide">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 opacity-90" />
              <span>10 – 12 July 2026</span>
            </div>
            <div className="w-px h-3 bg-white/30 hidden sm:block" />
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 opacity-90" />
              <span>Sankara Eye Hospital, Bangalore</span>
            </div>
          </div>
        </div>

        {/* Main Form Box */}
        <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-8 z-10">
          <div
            className={`w-full max-w-md transition-all duration-700 flex flex-col ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
          >
            {/* Three-Logo Header Banner Above Login Form */}
            <div className="w-full bg-white border border-slate-250 rounded-2xl shadow-md p-3.5 mb-4 flex justify-center items-center shrink-0">
              <img src={bannerImg} alt="Vision 2020 Conference Header Banner" className="max-h-12 w-auto object-contain" />
            </div>

            {/* Main Card - Clean Light Theme */}
            <div className="bg-white border border-slate-250 rounded-3xl shadow-xl overflow-y-auto sm:overflow-hidden flex flex-col max-h-full">

              {/* BRAND LOGOS HEADER */}
              <div className="px-6 pt-5 pb-3 flex items-center justify-between border-b border-slate-100 bg-slate-50/80">
                <div className="flex items-center gap-3">
                  <img
                    src={sankaraLogo}
                    alt="Sankara Logo"
                    className="w-9 h-9 object-contain"
                  />
                  <div className="h-6 w-px bg-slate-200" />
                  <div className="min-w-0">
                    <h2 className="text-slate-800 font-black text-sm sm:text-base tracking-tight leading-none uppercase">Vision 2020</h2>
                    <p className="text-[#F58220] text-[10px] sm:text-xs font-black tracking-wider mt-1 uppercase">Sankara India</p>
                  </div>
                </div>
                <div>
                  {gateway === "staff" ? (
                    <button
                      type="button"
                      onClick={() => handleGatewayChange("delegate")}
                      className="text-[11px] font-extrabold text-[#F58220] hover:text-white bg-[#F58220]/10 hover:bg-[#F58220] border border-[#F58220]/25 px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" /> Back
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleGatewayChange("staff")}
                      className="text-[11px] font-extrabold text-slate-550 hover:text-white bg-slate-100 hover:bg-slate-700 border border-slate-250 px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                    >
                      <Lock className="w-3.5 h-3.5" /> Staff Login
                    </button>
                  )}
                </div>
              </div>

              {/* GATEWAY SELECTOR PILLS */}
              {gateway !== "staff" && (
                <div className="p-3 bg-slate-50 border-b border-slate-150">
                  <div className="grid grid-cols-2 gap-2 bg-slate-150 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => handleGatewayChange("delegate")}
                      className={`py-3.5 rounded-lg text-xs sm:text-sm font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${gateway === "delegate"
                        ? "bg-[#F58220] text-white shadow-sm"
                        : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
                        }`}
                    >
                      <Calendar className="w-4 h-4 shrink-0" />
                      Delegate Schedule
                    </button>
                    <button
                      type="button"
                      onClick={() => handleGatewayChange("presenter")}
                      className={`py-3.5 rounded-lg text-xs sm:text-sm font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${gateway === "presenter"
                        ? "bg-[#6F42C1] text-white shadow-sm"
                        : "text-slate-600 hover:text-slate-900 hover:bg-slate-200/50"
                        }`}
                    >
                      <Upload className="w-4 h-4 shrink-0" />
                      Faculty Upload
                    </button>
                  </div>
                </div>
              )}

              {/* GATEWAY FORMS */}
              <div className="px-5 py-5 flex-1 bg-white">

                {/* Informative description & Step-by-Step guides */}
                {gateway === "delegate" && (
                  <div className="mb-3.5 p-2.5 rounded-xl bg-orange-50 border border-orange-100 text-slate-800 space-y-1 animate-in fade-in duration-200">
                    <div className="font-extrabold text-[11px] sm:text-xs flex items-center gap-1 text-orange-700">
                      <Calendar className="w-3.5 h-3.5" /> Delegate Portal
                    </div>
                    <div className="text-[10px] sm:text-[11px] text-slate-500 leading-snug font-semibold">
                      Enter registered Email ID ➔ Verify OTP (sent to Email &amp; WhatsApp) to view and RSVP sessions.
                    </div>
                  </div>
                )}

                {gateway === "presenter" && (
                  <div className="mb-4 p-3 rounded-2xl bg-purple-50 border border-purple-100 text-slate-800 space-y-1.5 animate-in fade-in duration-200">
                    <div className="font-extrabold text-xs sm:text-sm flex items-center gap-1.5 text-purple-700">
                      <Upload className="w-4 h-4" /> Presenter &amp; Speaker Uploads
                    </div>
                    <div className="text-[11px] sm:text-xs text-slate-600 leading-relaxed font-semibold">
                      Upload and manage slide materials:
                      <ul className="list-decimal list-inside mt-1.5 space-y-1 text-[11px] sm:text-[11px] text-slate-500 font-semibold">
                        <li>Enter your registered Email ID.</li>
                        <li>Verify with OTP on first visit to configure a secure <strong className="text-purple-700 font-extrabold">6-digit passcode (PIN)</strong>.</li>
                        <li>On your next visit, select "Passcode Mode" to log in instantly without OTP.</li>
                      </ul>
                    </div>
                  </div>
                )}

                {/* COORD & STAFF PASSWORD LOGIN FORM */}
                {gateway === "staff" && (
                  <div className="mb-4 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 space-y-1.5 animate-in fade-in duration-200">
                    <div className="font-extrabold text-xs sm:text-sm flex items-center gap-1.5 text-slate-800">
                      <Lock className="w-4 h-4 text-[#F58220]" /> Staff Scanning Console
                    </div>
                    <p className="text-[11px] sm:text-xs text-slate-500 leading-relaxed font-semibold">
                      For coordinators, goodies desk, and food scanning team. Log in with your Employee ID/Mobile and Password.
                    </p>
                  </div>
                )}

                {showStaffForgotMsg && (
                  <div className="mb-4 p-3.5 bg-orange-50 border border-orange-200 text-orange-855 rounded-xl text-xs font-semibold leading-relaxed animate-in fade-in duration-200 relative">
                    <button
                      type="button"
                      onClick={() => setShowStaffForgotMsg(false)}
                      className="absolute right-2.5 top-2.5 text-orange-600 hover:text-orange-950 font-black text-sm"
                    >
                      ✕
                    </button>
                    If you forgot your password, please contact <strong className="text-orange-950">prabhanjan@sankaraeye.com</strong> for assistance and to request a password reset.
                  </div>
                )}

                {((gateway === "delegate" || (gateway === "presenter" && presenterLoginMode === "otp")) && otpStep === "email") && (
                  <form onSubmit={(e) => { e.preventDefault(); handleParticipantEmailSubmit("email"); }} className="space-y-4 animate-in fade-in duration-200">
                    <div className="space-y-1.5">
                      <Label htmlFor="email-input" className="text-slate-700 text-sm sm:text-base font-extrabold">
                        Registered Email Address / Mobile / Reg No
                      </Label>
                      <div className="relative">
                        <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                          id="email-input"
                          type="text"
                          placeholder="Enter registered email, mobile or Reg No"
                          value={emailInput}
                          onChange={(e) => setEmailInput(e.target.value)}
                          required
                          className="pl-10 h-12 bg-white border border-slate-355 text-slate-800 placeholder:text-slate-400 focus:border-[#F58220] focus:ring-[#F58220]/25 rounded-xl text-base font-semibold transition-all outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <Button
                        type="button"
                        onClick={() => handleParticipantEmailSubmit("email")}
                        disabled={loading || !emailInput.trim()}
                        className="w-full h-12 text-white font-extrabold text-sm rounded-xl shadow-xs transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer bg-[#F58220] hover:bg-[#ff963d]"
                      >
                        {loading && loginOtpChannel === "email" ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Mail className="w-4 h-4" />
                        )}
                        <span>OTP via Email</span>
                      </Button>
                      <Button
                        type="button"
                        onClick={() => handleParticipantEmailSubmit("whatsapp")}
                        disabled={loading || !emailInput.trim()}
                        className="w-full h-12 text-white font-extrabold text-sm rounded-xl shadow-xs transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer bg-[#25D366] hover:bg-[#1ebd5b]"
                      >
                        {loading && loginOtpChannel === "whatsapp" ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Phone className="w-4 h-4" />
                        )}
                        <span>OTP via WhatsApp</span>
                      </Button>
                    </div>

                    {gateway === "presenter" && (
                      <div className="pt-2 space-y-2">
                        <div className="flex justify-between items-center text-xs sm:text-sm font-bold">
                          <button
                            type="button"
                            onClick={() => setPresenterLoginMode("passcode")}
                            className="text-purple-600 hover:underline cursor-pointer"
                          >
                            Log in using Passcode Instead
                          </button>
                          <Link href="/set-password">
                            <span className="text-slate-400 hover:text-slate-650 cursor-pointer font-bold">Setup Passcode</span>
                          </Link>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          className="w-full h-12 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl transition-all cursor-pointer text-sm sm:text-base flex items-center justify-center gap-2 mt-2"
                          onClick={() => window.location.href = "/tracks"}
                        >
                          <Calendar className="w-4 h-4 text-[#F58220]" />
                          View Tracks &amp; RSVP
                        </Button>
                      </div>
                    )}

                    {gateway === "delegate" && (
                      <div className="space-y-2">
                        <div className="grid grid-cols-3 gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            className="h-10 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl transition-all cursor-pointer text-[10px] sm:text-xs flex items-center justify-center gap-1 px-1"
                            onClick={() => window.open("/brochurev2020", "_blank")}
                          >
                            <FileText className="w-3.5 h-3.5 text-[#F58220]" />
                            Brochure
                          </Button>

                          <Button
                            type="button"
                            variant="outline"
                            className="h-10 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl transition-all cursor-pointer text-[10px] sm:text-xs flex items-center justify-center gap-1 px-1"
                            onClick={() => window.open("https://ac.vision2020india.org/", "_blank")}
                          >
                            <Star className="w-3.5 h-3.5 text-[#F58220]" />
                            About Event
                          </Button>

                          <Button
                            type="button"
                            variant="outline"
                            className="h-10 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl transition-all cursor-pointer text-[10px] sm:text-xs flex items-center justify-center gap-1 px-1"
                            onClick={() => window.open(conferenceMapUrl || "https://maps.app.goo.gl/AAj5SfyoMqpJHDKP7", "_blank")}
                          >
                            <MapPin className="w-3.5 h-3.5 text-[#F58220]" />
                            Venue Map
                          </Button>
                        </div>

                        <Button
                          type="button"
                          variant="outline"
                          className="w-full h-10 border-[#6F42C1]/20 bg-purple-50/30 hover:bg-purple-50 text-[#6F42C1] font-bold rounded-xl transition-all cursor-pointer text-xs flex items-center justify-center gap-1.5"
                          onClick={() => window.location.href = "/tracks"}
                        >
                          <Calendar className="w-4 h-4 text-[#6F42C1]" />
                          View Tracks &amp; RSVP
                        </Button>
                      </div>
                    )}
                  </form>
                )}

                {/* OTP CODE STEP */}
                {((gateway === "delegate" || gateway === "presenter") && otpStep === "otp") && (
                  <form onSubmit={handleParticipantOtpVerify} className="space-y-5 animate-in fade-in duration-200">
                    <div className="space-y-2 text-center">
                      <Label className="text-slate-800 font-extrabold text-sm sm:text-base">
                        Enter Verification Code
                      </Label>
                      <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                        {otpSentMessage}
                      </p>
                    </div>

                    <div className="py-2 flex justify-center">
                      <OtpInput
                        value={otpValue}
                        onChange={setOtpValue}
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setOtpStep("email");
                          setOtpValue("");
                        }}
                        className="flex-1 h-12 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl transition-all cursor-pointer text-sm sm:text-base"
                      >
                        Back
                      </Button>
                      <Button
                        type="submit"
                        className={`flex-[2] h-12 text-white font-black text-sm sm:text-base rounded-xl shadow-xs transition-all duration-300 cursor-pointer ${
                          gateway === "delegate"
                            ? "bg-[#F58220] hover:bg-[#ff963d]"
                            : "bg-[#6F42C1] hover:bg-[#8050d9]"
                        }`}
                        disabled={loading || otpValue.length !== 6}
                      >
                        {loading ? (
                          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Verifying...</>
                        ) : (
                          "Verify & Access Portal"
                        )}
                      </Button>
                    </div>
                  </form>
                )}

                {/* PRESENTER PASSCODE LOGIN MODE */}
                {(gateway === "presenter" && presenterLoginMode === "passcode" && otpStep === "email") && (
                  <form onSubmit={handlePresenterPasscodeLogin} className="space-y-4 animate-in fade-in duration-200">
                    <div className="space-y-1.5">
                      <Label htmlFor="presenter-email" className="text-slate-700 text-sm sm:text-base font-extrabold">
                        Registered Email Address
                      </Label>
                      <div className="relative">
                        <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                          id="presenter-email"
                          type="email"
                          placeholder="Enter your registered email"
                          value={emailInput}
                          onChange={(e) => setEmailInput(e.target.value)}
                          required
                          className="pl-10 h-12 bg-white border border-slate-355 text-slate-800 placeholder:text-slate-400 focus:border-[#F58220] focus:ring-[#F58220]/25 rounded-xl text-base font-semibold transition-all outline-none"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-slate-700 text-sm sm:text-base font-extrabold block text-left">
                        6-Digit Passcode
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                          id="presenter-passcode"
                          type={showPasscodeField ? "text" : "password"}
                          placeholder="Enter your 6-character passcode"
                          value={passcodeInput}
                          onChange={(e) => setPasscodeInput(e.target.value)}
                          maxLength={20}
                          required
                          autoComplete="current-password"
                          className="pl-10 pr-10 h-12 bg-white border border-slate-300 text-slate-800 placeholder:text-slate-400 focus:border-[#6F42C1] focus:ring-[#6F42C1]/25 rounded-xl text-base font-semibold transition-all outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPasscodeField(!showPasscodeField)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition-colors"
                          tabIndex={-1}
                        >
                          {showPasscodeField ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-12 bg-[#6F42C1] hover:bg-[#8050d9] text-white font-black text-base rounded-xl shadow-xs transition-all duration-355 cursor-pointer"
                      disabled={loading || !emailInput.trim() || !passcodeInput.trim()}
                    >
                      {loading ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> Verifying Passcode...</>
                      ) : (
                        "Sign In with Passcode"
                      )}
                    </Button>

                    <div className="pt-2 space-y-2">
                      <div className="flex justify-between items-center text-xs sm:text-sm font-bold">
                        <button
                          type="button"
                          onClick={() => setPresenterLoginMode("otp")}
                          className="text-purple-600 hover:underline cursor-pointer"
                        >
                          Login via OTP Code Instead
                        </button>
                        <Link href="/set-password">
                          <span className="text-slate-400 hover:text-slate-650 cursor-pointer font-bold">Setup Passcode</span>
                        </Link>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full h-12 border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl transition-all cursor-pointer text-sm sm:text-base flex items-center justify-center gap-2 mt-2"
                        onClick={() => window.location.href = "/tracks"}
                      >
                        <Calendar className="w-4 h-4 text-[#F58220]" />
                        View Tracks &amp; RSVP
                      </Button>
                    </div>
                  </form>
                )}

                {/* COORD & STAFF PASSWORD LOGIN FORM */}
                {(gateway === "staff") && (
                  <form onSubmit={handleStaffLogin} className="space-y-4 animate-in fade-in duration-200">
                    <div className="space-y-1.5">
                      <Label htmlFor="staff-id" className="text-slate-700 text-sm sm:text-base font-extrabold">
                        EMP ID or Mobile Number
                      </Label>
                      <div className="relative">
                        <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                          id="staff-id"
                          placeholder="Enter EMP ID or mobile"
                          value={staffIdentifier}
                          onChange={(e) => setStaffIdentifier(e.target.value)}
                          required
                          className="pl-10 h-12 bg-white border border-slate-350 text-slate-800 placeholder:text-slate-400 focus:border-[#F58220] focus:ring-[#F58220]/25 rounded-xl text-base font-semibold transition-all outline-none"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <Label htmlFor="staff-pwd" className="text-slate-700 text-sm sm:text-base font-extrabold">
                          {useStaffPasscode ? "Enter 6-Digit PIN Passcode" : "Enter Alphanumeric Password"}
                        </Label>
                        <div className="flex gap-3 items-center">
                          <button
                            type="button"
                            onClick={() => {
                              setUseStaffPasscode(!useStaffPasscode);
                              setStaffPassword("");
                            }}
                            className="text-xs text-purple-600 hover:text-[#6F42C1] cursor-pointer font-black transition-colors outline-none"
                          >
                            {useStaffPasscode ? "First Time Login?" : "Use PIN Passcode"}
                          </button>
                          <span className="text-slate-200">|</span>
                          <button
                            type="button"
                            onClick={() => setShowStaffForgotMsg(true)}
                            className="text-xs text-slate-450 hover:text-[#F58220] cursor-pointer font-extrabold transition-colors outline-none"
                          >
                            Forgot?
                          </button>
                        </div>
                      </div>

                      {useStaffPasscode ? (
                        <div className="py-2 flex justify-center">
                          <PasscodeInput
                            value={staffPassword}
                            onChange={setStaffPassword}
                            theme="light"
                          />
                        </div>
                      ) : (
                        <div className="relative">
                          <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                          <Input
                            id="staff-pwd"
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter staff alphanumeric password (e.g. welcome@123)"
                            value={staffPassword}
                            onChange={(e) => setStaffPassword(e.target.value)}
                            required
                            autoComplete="current-password"
                            className="pl-10 pr-10 h-12 bg-white border border-slate-355 text-slate-800 placeholder:text-slate-400 focus:border-[#F58220] focus:ring-[#F58220]/25 rounded-xl text-base font-semibold transition-all outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition-colors"
                            tabIndex={-1}
                          >
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      )}
                    </div>



                    <Button
                      type="submit"
                      className="w-full h-12 bg-[#F58220] hover:bg-[#ff963d] text-white font-black text-base rounded-xl shadow-xs transition-all duration-300 cursor-pointer"
                      disabled={loading || !staffIdentifier || !staffPassword}
                    >
                      {loading ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> Checking credentials...</>
                      ) : (
                        "Sign In to Coordinator Console"
                      )}
                    </Button>

                  </form>
                )}

              </div>

              {gateway !== "staff" && (
                <div className="px-6 pb-5 pt-1">
                  <Button
                    type="button"
                    className="w-full h-11 text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-1.5 bg-[#25D366] hover:bg-[#1ebd5b] border-0 cursor-pointer transition-all shadow-md shadow-emerald-500/10"
                    onClick={() => window.open("https://chat.whatsapp.com/G0f3VAqJVCq69zuakppm7H", "_blank")}
                  >
                    <MessageSquare className="w-4 h-4 text-white" />
                    <span>Join Conference WhatsApp Group</span>
                  </Button>
                </div>
              )}

              {/* CARD BRAND FOOTER */}
              <div className="py-4 px-6 border-t border-slate-100 bg-slate-50/50 flex items-center justify-center gap-1.5 text-slate-400 text-[10.5px] font-bold text-center">
                <span>Sankara Eye Foundation India - Vision 2020 20th Annual Meet</span>
              </div>

            </div>

            {/* Mobile Milestones Card */}
            <div className="mt-5 w-full bg-white border border-slate-200 rounded-2xl p-3.5 shadow-sm flex justify-around items-center text-center divide-x divide-slate-100 select-none">
              <div className="flex-1 px-1">
                <span className="block text-sm font-black text-[#F58220]">3M+</span>
                <span className="block text-[8px] sm:text-[9px] text-slate-500 font-bold tracking-tight mt-0.5 leading-tight uppercase">Free Surgeries<br/>Across India</span>
              </div>
              <div className="flex-1 px-1">
                <span className="block text-sm font-black text-[#6F42C1]">50 Yrs</span>
                <span className="block text-[8px] sm:text-[9px] text-slate-500 font-bold tracking-tight mt-0.5 leading-tight uppercase">Of Dedicated<br/>Service</span>
              </div>
              <div className="flex-1 px-1">
                <span className="block text-sm font-black text-amber-600">Since 1977</span>
                <span className="block text-[8px] sm:text-[9px] text-slate-500 font-bold tracking-tight mt-0.5 leading-tight uppercase">Championing<br/>Eye Care</span>
              </div>
            </div>



            <p className="text-center text-slate-400/80 text-[10px] font-bold mt-4 tracking-wide">
              © 2026 Sankara Eye Foundation. All Rights Reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
