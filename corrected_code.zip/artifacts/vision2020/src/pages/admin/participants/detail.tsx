import { useParams, Link } from "wouter";
import { useGetParticipant, getGetParticipantQueryKey, useGetParticipantQR, getGetParticipantQRQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Calendar, MapPin, Clock, Download, CheckSquare, Gift, Utensils, CalendarDays, User, QrCode } from "lucide-react";

const FACULTY_ROLES = ["Speaker", "Presenter", "Poster", "Panelist", "Moderator", "Judge", "Chair", "CoChair"];
const ROLE_COLOR: Record<string, string> = {
  Speaker: "bg-blue-100 text-blue-800 border-blue-200",
  Presenter: "bg-indigo-100 text-indigo-800 border-indigo-200",
  Poster: "bg-cyan-100 text-cyan-800 border-cyan-200",
  Panelist: "bg-violet-100 text-violet-800 border-violet-200",
  Moderator: "bg-purple-100 text-purple-800 border-purple-200",
  Judge: "bg-amber-100 text-amber-800 border-amber-200",
  Chair: "bg-orange-100 text-orange-800 border-orange-200",
  CoChair: "bg-rose-100 text-rose-800 border-rose-200",
};

export default function AdminParticipantDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || "0", 10);

  const { data: participant, isLoading } = useGetParticipant(id, {
    query: { enabled: !!id, queryKey: getGetParticipantQueryKey(id) }
  });

  const assignments = participant?.assignments || [];
  const isFaculty = assignments.some(a => FACULTY_ROLES.includes(a.role));

  const { data: qrcodes, isLoading: isQRLoading } = useGetParticipantQR(id, {
    query: { enabled: !!id && !!participant, queryKey: getGetParticipantQRQueryKey(id) }
  });

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-4">
        <Link href="/admin/participants">
          <Button variant="outline" size="icon">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Participant Details</h1>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-6">
          <Skeleton className="h-40 rounded-2xl" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Skeleton className="h-64 lg:col-span-2" />
            <Skeleton className="h-64" />
          </div>
        </div>
      ) : participant ? (
        <div className="space-y-6">
          {/* Profile Banner */}
          <div className="bg-gradient-to-r from-[#6F42C1] to-[#5a35a0] rounded-2xl p-6 text-white shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                <User className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-xl font-bold truncate">{participant.name}</h2>
                <p className="text-white/80 text-sm mt-0.5">{participant.institution}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {[...new Set(assignments.map(a => a.role))].length > 0 ? (
                    [...new Set(assignments.map(a => a.role))].map(role => (
                      <span key={role} className="px-2 py-0.5 bg-white/20 rounded-full text-xs font-semibold">{role}</span>
                    ))
                  ) : (
                    <span className="px-2 py-0.5 bg-white/20 rounded-full text-xs font-semibold">Participant</span>
                  )}
                </div>
              </div>
              <div className="sm:text-right shrink-0">
                <div className="text-xs text-white/70 uppercase tracking-wide">Registration No.</div>
                <div className="text-xl font-mono font-bold mt-0.5">{participant.registrationNumber}</div>
                <div className="mt-2">
                  {participant.hasPassword ? (
                    <Badge className="bg-green-400/30 text-green-100 border-green-300/30 text-xs">Account Active</Badge>
                  ) : (
                    <Badge className="bg-white/20 text-white/70 border-white/20 text-xs">No Login Setup</Badge>
                  )}
                </div>
              </div>
            </div>

            {/* Profile fields */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-5 pt-5 border-t border-white/20">
              <div>
                <div className="text-xs text-white/60 font-medium uppercase tracking-wide">Email</div>
                <div className="text-sm text-white mt-0.5 break-all text-xs sm:text-sm">{participant.email || "—"}</div>
              </div>
              <div>
                <div className="text-xs text-white/60 font-medium uppercase tracking-wide">Mobile</div>
                <div className="text-sm text-white mt-0.5 font-mono">{participant.mobile || "—"}</div>
              </div>
              <div>
                <div className="text-xs text-white/60 font-medium uppercase tracking-wide">Faculty Status</div>
                <div className="text-sm text-white mt-0.5">{isFaculty ? "Faculty" : "Regular Participant"}</div>
              </div>
              <div>
                <div className="text-xs text-white/60 font-medium uppercase tracking-wide">Payment Status</div>
                <div className="text-sm mt-0.5 font-bold">
                  {participant.isPaid ? (
                    <span className="text-green-300">Paid ✓</span>
                  ) : participant.isSponsored ? (
                    <span className="text-purple-300 uppercase">Sponsored ({participant.sponsorType === "sefi" ? "SEFI" : "Vision2020"})</span>
                  ) : (
                    <span className="text-red-300">Unpaid ⚠️</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Tabs column (takes 2 columns) */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="schedule" className="w-full">
                <TabsList className="bg-slate-100 border border-slate-200 p-1 rounded-xl h-auto flex gap-0.5 shadow-sm mb-4">
                  <TabsTrigger 
                    value="schedule" 
                    className="rounded-lg py-2 px-4 font-bold text-sm gap-1.5 shrink-0 data-[state=active]:bg-[#6F42C1] data-[state=active]:text-white transition-all duration-200"
                  >
                    <Calendar className="w-3.5 h-3.5" /> Roles & Schedule
                  </TabsTrigger>
                  <TabsTrigger 
                    value="logs" 
                    className="rounded-lg py-2 px-4 font-bold text-sm gap-1.5 shrink-0 data-[state=active]:bg-[#6F42C1] data-[state=active]:text-white transition-all duration-200"
                  >
                    <CheckSquare className="w-3.5 h-3.5" /> Check-in & Logs
                  </TabsTrigger>
                  <TabsTrigger 
                    value="profile" 
                    className="rounded-lg py-2 px-4 font-bold text-sm gap-1.5 shrink-0 data-[state=active]:bg-[#6F42C1] data-[state=active]:text-white transition-all duration-200"
                  >
                    <User className="w-3.5 h-3.5" /> Full Profile
                  </TabsTrigger>
                </TabsList>

                {/* Tab 1: Roles & Schedule */}
                <TabsContent value="schedule">
                  <Card className="border-gray-100 shadow-sm">
                    <CardHeader className="pb-3 border-b border-gray-100">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-500" /> Assigned Roles & Timetable
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-5">
                      {assignments.length > 0 ? (
                        <div className="space-y-4">
                          {assignments.map(assignment => (
                            <div key={assignment.id} className="border border-gray-100 rounded-xl p-4 bg-gray-50/50">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge
                                  variant="outline"
                                  className={`text-xs font-semibold ${ROLE_COLOR[assignment.role] || "bg-gray-100 text-gray-700 border-gray-200"}`}
                                >
                                  {assignment.role}
                                </Badge>
                                <span className="text-xs text-gray-500 font-medium">{assignment.track}</span>
                              </div>

                              {assignment.presentationTitle && (
                                <h4 className="font-semibold text-gray-900 text-sm mb-1">{assignment.presentationTitle}</h4>
                              )}
                              {assignment.sessionName && (
                                <div className="text-xs text-gray-600 mb-2">{assignment.sessionName}</div>
                              )}

                              <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                                {assignment.date && <div className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {assignment.date}</div>}
                                {assignment.time && <div className="flex items-center gap-1"><Clock className="w-3 h-3" /> {assignment.time}</div>}
                                {assignment.hall && <div className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {assignment.hall}</div>}
                              </div>

                              {assignment.uploadedFile && (
                                <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
                                  <span className="text-xs text-green-700 font-medium">
                                    ✓ {assignment.uploadedFile.originalName}
                                  </span>
                                  <a
                                    href={`/api/assignments/${assignment.id}/file/download?token=${encodeURIComponent(localStorage.getItem("vision2020_token") || "")}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="text-xs text-[#6F42C1] font-medium hover:underline"
                                  >
                                    Download
                                  </a>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="py-10 text-center text-gray-400 text-sm">No assigned roles for this participant.</div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Tab 2: Check-in & Logs */}
                <TabsContent value="logs">
                  <Card className="border-gray-100 shadow-sm">
                    <CardHeader className="pb-3 border-b border-gray-100">
                      <CardTitle className="text-base flex items-center gap-2">
                        <CheckSquare className="w-4 h-4 text-gray-500" /> Attendance & Coupon Claims
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-5 space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Attendance Scanner Log */}
                        <div className={`p-4 rounded-xl border flex items-center justify-between ${participant.attendanceMarked ? "bg-emerald-50 border-emerald-100 text-emerald-800" : "bg-slate-50 border-slate-200 text-slate-500"}`}>
                          <div>
                            <div className="text-xs font-bold uppercase tracking-wider">Attendance Check-in</div>
                            <div className="text-sm font-semibold mt-1">
                              {participant.attendanceMarked ? "Marked / Checked In" : "Not Scanned Yet"}
                            </div>
                            {participant.attendanceScannedAt && (
                              <div className="text-[10px] text-emerald-600 mt-1">
                                {new Date(participant.attendanceScannedAt).toLocaleString("en-IN")}
                              </div>
                            )}
                          </div>
                          <CheckSquare className={`w-8 h-8 ${participant.attendanceMarked ? "text-emerald-500" : "text-slate-300"}`} />
                        </div>

                        {/* Goodies Scanner Log */}
                        <div className={`p-4 rounded-xl border flex items-center justify-between ${participant.goodiesCollected ? "bg-emerald-50 border-emerald-100 text-emerald-800" : "bg-slate-50 border-slate-200 text-slate-500"}`}>
                          <div>
                            <div className="text-xs font-bold uppercase tracking-wider">Conference Goodies Kit</div>
                            <div className="text-sm font-semibold mt-1">
                              {participant.goodiesCollected ? "Collected" : "Not Collected"}
                            </div>
                            {participant.goodiesCollectedAt && (
                              <div className="text-[10px] text-emerald-600 mt-1">
                                {new Date(participant.goodiesCollectedAt).toLocaleString("en-IN")}
                              </div>
                            )}
                          </div>
                          <Gift className={`w-8 h-8 ${participant.goodiesCollected ? "text-emerald-500" : "text-slate-300"}`} />
                        </div>
                      </div>

                      {/* Food Logs list */}
                      <div>
                        <h4 className="text-sm font-bold text-gray-700 flex items-center gap-1.5 mb-3">
                          <Utensils className="w-4 h-4 text-purple-650" /> Food Coupon Claims
                        </h4>
                        <div className="space-y-2">
                          {participant.foodCoupons && participant.foodCoupons.length > 0 ? (
                            participant.foodCoupons.map((coupon: any) => (
                              <div
                                key={coupon.foodSessionId}
                                className={`flex items-center justify-between p-3.5 rounded-xl border text-xs transition-all ${
                                  coupon.collected
                                    ? "bg-purple-50/50 border-purple-150 text-purple-900 font-semibold"
                                    : "bg-slate-50 border-slate-100 text-slate-400"
                                }`}
                              >
                                <div>
                                  <div className="font-bold text-sm text-gray-800">{coupon.name}</div>
                                  <div className="text-gray-500 mt-0.5">{coupon.date}</div>
                                </div>
                                {coupon.collected ? (
                                  <div className="text-right">
                                    <Badge className="bg-purple-100 text-purple-800 border-purple-200 font-black">CLAIMED</Badge>
                                    {coupon.collectedAt && (
                                      <div className="text-[9px] text-purple-500 mt-1">
                                        {new Date(coupon.collectedAt).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" })}
                                      </div>
                                    )}
                                  </div>
                                ) : (
                                  <span className="font-semibold text-slate-400">UNCLAIMED</span>
                                )}
                              </div>
                            ))
                          ) : (
                            <p className="text-center py-6 text-gray-400 text-xs">No food coupon logs found.</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Tab 3: Full Profile */}
                <TabsContent value="profile">
                  <Card className="border-gray-100 shadow-sm">
                    <CardHeader className="pb-3 border-b border-gray-100">
                      <CardTitle className="text-base flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-500" /> Registration & Payment Details
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {[
                          { label: "Full Name", value: participant.name },
                          { label: "Registration No.", value: participant.registrationNumber },
                          { label: "Institution / Hospital", value: participant.institution },
                          { label: "Registered Email", value: participant.email },
                          { label: "Mobile Number", value: participant.mobile },
                          { label: "Delegate Type", value: participant.delegateType, className: "uppercase" },
                          { label: "Payment Method", value: participant.isSponsored ? `Sponsor (${participant.sponsorType?.toUpperCase()})` : (participant.isPaid ? `Self-Paid (UTR: ${participant.utrNumber || "—"})` : "Unpaid") },
                          { label: "Registered At", value: new Date(participant.createdAt).toLocaleString("en-IN") }
                        ].map((field) => (
                          <div key={field.label} className="border-b border-gray-100 pb-3">
                            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">{field.label}</span>
                            <span className={`text-sm font-semibold text-gray-800 mt-1 block ${field.className || ""}`}>{field.value || "—"}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* QR Codes — right column */}
            <div>
              <Card className="border-gray-100 shadow-sm overflow-hidden sticky top-6">
                <div className="bg-gradient-to-r from-[#F58220] to-[#e07010] px-5 py-4">
                  <div className="flex items-center gap-2 text-white">
                    <QrCode className="w-5 h-5" />
                    <div>
                      <div className="font-semibold text-sm">Participant QR Codes</div>
                      <div className="text-xs text-white/70">Download for printing</div>
                    </div>
                  </div>
                </div>

                {isQRLoading ? (
                  <div className="p-6 flex justify-center">
                    <Skeleton className="w-44 h-44 rounded-xl" />
                  </div>
                ) : qrcodes ? (
                  <Tabs defaultValue="qr1" className="w-full">
                    <div className="px-4 pt-4">
                      <TabsList className="w-full grid grid-cols-2">
                        <TabsTrigger value="qr1" className="text-xs">Registration</TabsTrigger>
                        <TabsTrigger value="qr2" className="text-xs">Agenda Portal</TabsTrigger>
                      </TabsList>
                    </div>

                    {/* Registration QR */}
                    <TabsContent value="qr1" className="px-4 pb-4 pt-3 flex flex-col items-center">
                      <div className="bg-white p-2.5 rounded-xl border-2 border-[#F58220]/30 shadow-sm mb-3">
                        <img src={qrcodes.qr1.dataUrl} alt="Registration QR" className="w-40 h-40" />
                      </div>
                      <p className="text-xs font-bold text-gray-800 mb-2 text-center">Registration Badge</p>
                      <div className="w-full space-y-1.5 mb-3">
                        {[
                          { icon: CheckSquare, label: "Attendance Check-in", color: "text-green-700 bg-green-50 border-green-200" },
                          { icon: Gift, label: "Goodies Collection", color: "text-purple-700 bg-purple-50 border-purple-200" },
                          { icon: Utensils, label: "Food Coupon / Meals", color: "text-orange-700 bg-orange-50 border-orange-200" },
                        ].map(({ icon: Icon, label, color }) => (
                          <div key={label} className={`flex items-center gap-2 px-2.5 py-1 rounded-lg border text-xs font-medium ${color}`}>
                            <Icon className="w-3 h-3 shrink-0" /> {label}
                          </div>
                        ))}
                      </div>
                      <Button variant="outline" size="sm" className="w-full h-8 text-xs gap-1.5" asChild>
                        <a href={qrcodes.qr1.dataUrl} download={qrcodes.qr1.downloadName}>
                          <Download className="w-3.5 h-3.5" /> Download
                        </a>
                      </Button>
                    </TabsContent>

                    {/* Agenda Portal QR */}
                    <TabsContent value="qr2" className="px-4 pb-4 pt-3 flex flex-col items-center">
                      <div className="bg-white p-2.5 rounded-xl border-2 border-gray-100 shadow-sm mb-3">
                        <img src={qrcodes.qr2.dataUrl} alt="Agenda QR" className="w-40 h-40" />
                      </div>
                      <p className="text-xs font-bold text-gray-800 mb-2 text-center">Agenda Portal Hub</p>
                      <div className="flex flex-col gap-1.5 w-full mb-3">
                        {[
                          { icon: CalendarDays, label: "General Conference Brochure", color: "text-blue-700 bg-blue-50 border-blue-200" },
                          { icon: User, label: "Personal Commitments & Status logs", color: "text-purple-700 bg-purple-50 border-purple-200" },
                        ].map(({ icon: Icon, label, color }) => (
                          <div key={label} className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-xs font-medium ${color}`}>
                            <Icon className="w-3 h-3 shrink-0" /> {label}
                          </div>
                        ))}
                      </div>
                      <Button variant="outline" size="sm" className="w-full h-8 text-xs gap-1.5" asChild>
                        <a href={qrcodes.qr2.dataUrl} download={qrcodes.qr2.downloadName}>
                          <Download className="w-3.5 h-3.5" /> Download
                        </a>
                      </Button>
                    </TabsContent>
                  </Tabs>
                ) : (
                  <div className="p-6 text-center text-gray-400 text-sm">Could not load QR codes.</div>
                )}
              </Card>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center text-gray-500">Participant not found.</div>
      )}
    </div>
  );
}
