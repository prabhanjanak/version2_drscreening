// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    // Use explicit plugin versions compatible with Android Gradle Plugin and Kotlin
    id("com.android.application") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.8.22" apply false
}

buildscript {
    repositories {
        google()
        mavenCentral()
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
