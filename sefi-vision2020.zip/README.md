# SEFI Vision 2020 (Android)

Lightweight Android WebView app that opens `https://events.sankaraeye.in`.

Features
- Full-screen WebView with in-app navigation (no external browser)
- JavaScript, DOM Storage, Cookies (including third-party cookies)
- Support for file uploads (camera, gallery, PDF, any file picker)
- Support for downloads (PDF, images, office docs, ZIP) via DownloadManager
- Material Design 3 theme (light/dark)
- Android 12+ SplashScreen API support
- Loading progress bar, swipe-to-refresh, friendly retry page when offline
- SSL error handling dialog
- Android 13 notification permission handling
- Release-ready Gradle configuration and ProGuard rules

Minimum SDK: 24
Target / Compile SDK: 34
Language: Kotlin

---

## Building locally

Requirements:
- JDK 17
- Android Studio (recommended) or CLI with Android SDK installed
- Gradle (wrapper is included if you generate wrapper jar)

Open the project in Android Studio (File -> Open) at the project root.

From command line:
- Debug APK: `./gradlew assembleDebug`
- Release APK: `./gradlew assembleRelease`

Release build produces APK at:
`app/build/outputs/apk/release/app-release.apk`

---

## GitHub Actions

A workflow is included at `.github/workflows/android.yml` that:
- Runs on ubuntu-latest
- Sets up Java 17 (Temurin)
- Caches Gradle
- Builds the release APK with `./gradlew assembleRelease`
- Uploads the APK as an artifact

To enable:
1. Push this repository to GitHub.
2. Go to Actions tab — workflow will run on push to `main` (see workflow filters).

Download the APK from the workflow run's "Artifacts" section.

---

## Notes

- Replace launcher icons in `app/src/main/res/mipmap-*` and `drawable/ic_launcher_foreground.xml`.
- Recommended: use Android Studio Image Asset generator to create all mipmap densities from your PNG.
- If you want me to push directly, grant write permission to the account I use; otherwise push locally.
