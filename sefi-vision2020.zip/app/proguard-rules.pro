# Keep everything needed for WebView and FileProvider
-keep class android.webkit.WebView { *; }
-keepclassmembers class * extends android.app.Activity {
    public void onCreate(...);
}

# Keep our main app classes used via reflection
-keep class com.sefi.vision2020.** { *; }

# Don't obfuscate file provider authorities lookup
-keepclassmembers class * {
    public static final int SOME_CONSTANT;
}
