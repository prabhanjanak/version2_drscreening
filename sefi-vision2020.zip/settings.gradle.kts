rootProject.name = "SEFI Vision 2020"
include(":app")
